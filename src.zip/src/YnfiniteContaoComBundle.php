<?php

namespace Ynfinite\ContaoComBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class YnfiniteContaoComBundle extends Bundle {
  
}

