<?php

$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['new'] = array("Neues Feld", "Neues Feld hinzufügen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['edit'] = array("Feld bearbeiten", "Feld bearbeiten");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['delete'] = array("Feld löschen", "Feld löschen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['show'] = array("Feld anzeigen", "Feld anzeigen");

$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['type_field'] = array("Feld", "Wählen Sie hier das Feld aus auf dass Sie filtern wollen.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['operation'] = array("Operation", "Wählen Sie hier aus wie das Feld behandelt werden soll. Bitte beachten Sie die Dokumentation für die Operationen.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['value'] = array("Wert", "Geben Sie hier den Wert ein auf den gefiltert werden soll. Wenn Sie keine Werte hinterlegen können Sie die Filter über Filterformulare im Frontend von Ihren Besuchern direkt bestücken lassen.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['value2'] = array("Zweiter Wert", "Manche Operationen benötigen einen zweiten Wert z.B. <==> (Bereich). Geben Sie den zweiten Wert hier ein.");

$GLOBALS['TL_LANG']['tl_ynfinite_filter_fields']['filter_field_legend'] = "Filterfeld Informationen";