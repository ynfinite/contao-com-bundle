<?php

	$GLOBALS['TL_LANG']['tl_page']['ynfinite_contentType'] = array("Hauptinhaltstyp", "Wählen Sie hier den Inhaltstyp aus der die Seiten bestimmt.");

	$GLOBALS['TL_LANG']['tl_ynfinite_filter_form_fields']['ynfinite_legend'] = "Ynfinite Inhalte";
?>