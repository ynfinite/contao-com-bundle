<?php

$GLOBALS['TL_LANG']['tl_ynfinite_cache']['delete'] = array("Cache invalidieren", "Gecachete Daten löschen.");
$GLOBALS['TL_LANG']['tl_ynfinite_cache']['show'] = array("Cache anzeigen", "Gecachete Daten anzeigen.");

$GLOBALS['TL_LANG']['tl_ynfinite_cache']['url'] = array("URL", "Aufgerufene URL.");
$GLOBALS['TL_LANG']['tl_ynfinite_cache']['methode'] = array("HTTP Methode", "Die HTTP Methode des Aufrufs.");
$GLOBALS['TL_LANG']['tl_ynfinite_cache']['data'] = array("Daten", "Daten des Requests.");
$GLOBALS['TL_LANG']['tl_ynfinite_cache']['result'] = array("Antwort", "Antwort von Ynfinite.");
$GLOBALS['TL_LANG']['tl_ynfinite_cache']['created'] = array("Erstellt am", "Zeitstempel des Erstellungsdatums.");
