<?php

$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['new'] = array("Neues Filterformular", "Neues Filterformular anlegen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['edit'] = array("Filterformular bearbeiten", "Filterformular bearbeiten");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['delete'] = array("Filterformular löschen", "Filterformular löschen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['show'] = array("Filterformular anzeigen", "Filterformular anzeigen");

$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['contentType'] = array("Inhaltstyp", "Wählen Sie hier den Inhaltstyp aus Ihrem Ynfinite den Sie filtern wollen.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['submitLabel'] = array("Text für Absenden-Schaltfläche", "Geben Sie hier den Text für die Absenden-Schaltfläche ein.");

$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['title_legend'] = "Titel";
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['content_legend'] = "Inhaltstyp";
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['config_legend'] = "Konfiguration";
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['text_legend'] = "Texte";
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['template_legend'] = "Template";
$GLOBALS['TL_LANG']['tl_ynfinite_filter_form']['expert_legend'] = "Experteneinstellungen";
