<?php

$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['new'] = array("Neues Feld", "Neues Feld anlegen");
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['edit'] = array("Feld bearbeiten", "Feld bearbeiten");
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['delete'] = array("Feld löschen", "Feld löschen");
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['show'] = array("Feld anzeigen", "Feld anzeigen");

$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['contentTypeField'] = array("Inhaltsfeld", "Wählen Sie hier das zu filternde Feld aus.");
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['operation'] = array("Operation", "Wählen Sie hier aus wie das Feld behandelt werden soll. Bitte beachten Sie die Dokumentation für die Operationen.");

$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['type_legend'] = "Typ und Feld";
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['fconfig_legend'] = "Konfiguration";
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['template_legend'] = "Template";
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['size_legend'] = "Größe";
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['options_legend'] = "Optionen";
$GLOBALS['TL_LANG']['tl_ynfinite_form_fields']['expert_legend'] = "Experteneinstellungen";
