<?php

$GLOBALS['TL_LANG']['MOD']['ynfinite'] = array("Ynfinite", "Ynfnite Funktionen");
$GLOBALS['TL_LANG']['MOD']['ynfinite_forms'] = array("Formulare", "Konfigurieren Sie Ynfinite Formulare um Daten von Ihrer Webseite in die Leads zu speichern");
$GLOBALS['TL_LANG']['MOD']['ynfinite_filter_forms'] = array("Filterformulare", "Konfigurieren Sie Formulare mit denen Inhalte aus Ihrem Ynfinite gefiltert werden können.");
$GLOBALS['TL_LANG']['MOD']['ynfinite_filter'] = array("Filter", "Filter für das Anzeigen von Inhalten anlegen.");

$GLOBALS['TL_LANG']['MOD']['ynfinite_cache'] = array("Cache", "Alle Inhalte und Formulare werden hier gecached.");

$GLOBALS['TL_LANG']['FMD']['ynfinite'] = "Ynfinite";
$GLOBALS['TL_LANG']['FMD']['ynfinite_article_list'] = array("Ynfinite Artikel-Liste", "Artikel-Liste die auf durch Ynfinite gesteuerte Artikel reagiert.");