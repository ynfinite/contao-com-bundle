<?php

$GLOBALS['TL_LANG']['tl_content']['ynfinite_form_id'] = array("Formular", "Wählen Sie hier eines der angelegten Formulare.");

$GLOBALS['TL_LANG']['tl_content']['ynfinite_filter_id'] = array("Filter", "Wählen Sie hier einen Filter aus. Der Filter muss ausgewählt sein und bestimmt sowohl den Inhaltstyp den die Liste abfrägt als auch die Grundeinstellungen.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_perPage'] = array("Inhalte pro Seite", "Geben Sie hier ein wieviele Inhalte pro Seite angezeigt werden sollen.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_filter_form_id'] = array("Filterformular", "Wählen Sie hier eine Filterformular aus. Das Filterformular kann vom Frontend der Webseite Daten abfragen um die Grundeinstellungen der Liste durch den Filter zu überschreiben.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_show_form'] = array("Formular anzeigen", "Klicken Sie hier wenn ein Formular angezeigt werden soll wenn in der Liste keine Ergebnisse enthalten sind (z.B. wenn die Suche einen Filter enthält).");

$GLOBALS['TL_LANG']['tl_content']['ynfinite_new_window'] = array("In neuem Fenster öffnen?", "Kreuzen Sie hier an wenn Sie möchten dass die Ergebnise des Filterformulars in einem neuen Fenster geöffnet werden.");

$GLOBALS['TL_LANG']['tl_content']['ynfinite_jumpTo'] = array("Weiterleitungsseite", "Wählen Sie hier eine Seite aus zu der Weitergeleitet werden soll für eine Detailansicht.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_template'] = array("Anzeigetemplate", "Wählen Sie hier ein Template aus wenn Sie möchten dass nicht das Standardtemplate verwendet wird.");

$GLOBALS['TL_LANG']['tl_content']['ynfinite_contentType'] = array("Inhaltstyp", "Wählen Sie hier den Inhaltstyp des Inhalts aus der angezeigt werden soll.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_content_id'] = array("Inhalts Id", "Geben Sie hier die ID des Inhaltes an den Sie laden wollen. Wenn Sie hier nichts angeben versucht Ynfinite einen Inhalt anhand der URL Daten zu laden. ACHTUNG: Sie brauchen ein Aliasfeld in Ihrem Inhaltstyp, sonst kann Ynfinite den Inhalt nur über die ID zuordnen.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_set_page_title'] = array("Seitentitel setzen?", "Hier ankreuzen um den Titel der Seite auf der der Inhalt angezeigt wird zu verändern.");
$GLOBALS['TL_LANG']['tl_content']['ynfinite_title_field'] = array("Feld für den Titel", "Wählen Sie hier das Feld aus dass für den Titel der Seite verwendet werden soll.");

$GLOBALS['TL_LANG']['tl_content']['title_legend'] = "Titel";

?>