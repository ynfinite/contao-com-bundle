<?php

	$GLOBALS['TL_LANG']['tl_article']['hideTroughYnfinite'] = array("Sichtbarkeit des Artikels durch Ynfinite steuern.", "Kreuzen Sie hier an wenn Sie die Sichtbarkeit dieses Artikels über ein Feld in Ynfinite steuern möchten.");

	$GLOBALS['TL_LANG']['tl_article']['ynfinite_contentType'] = array("Inhaltstyp", "Wählen Sie hier den Inhaltstyp aus der das Feld enthält dass für die Sichtbarkeit des Artikels zuständig ist.");	

	$GLOBALS['TL_LANG']['tl_article']['ynfinite_content_id'] = array("Inhalts Id", "Geben Sie hier die ID des Inhaltes an den Sie laden wollen. Wenn Sie hier nichts angeben versucht Ynfinite einen Inhalt anhand der URL Daten zu laden. ACHTUNG: Sie brauchen ein Aliasfeld in Ihrem Inhaltstyp, sonst kann Ynfinite den Inhalt nur über die ID zuordnen.");	

	$GLOBALS['TL_LANG']['tl_article']['ynfinite_publish_field'] = array("Veröffentlichen Feld", "Wählen Sie hier das Feld aus anhand dessen Ynfinit entscheiden soll ob der Artikel sichtbar ist oder nicht. Dieses Feld sollte eine Checkbox um zerverlässig zu funktionieren.");	

	$GLOBALS['TL_LANG']['tl_article']['ynfinite_legend'] = "Ynfinite Einstellungen";
?>