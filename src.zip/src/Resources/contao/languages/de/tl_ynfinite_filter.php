<?php

$GLOBALS['TL_LANG']['tl_ynfinite_filter']['new'] = array("Neuen Filter", "Neuen Filter anlegen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['edit'] = array("Filter bearbeiten", "Filter bearbeiten");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['delete'] = array("Filter löschen", "Filter löschen");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['show'] = array("Filter anzeigen", "Filter anzeigen");

$GLOBALS['TL_LANG']['tl_ynfinite_filter']['title'] = array("Titel", "Geben Sie hier den Titel des Formulars an.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['contentType'] = array("Inhaltstyp", "Wählen Sie hier einen der Inhaltstypen aus Ihrem Ynfinite aus.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['useTags'] = array("Interessengruppen filter?", "Wählen Sie diesen Schalter um die Inhalte die mit diesem Filter geladen werden nach den Interessengruppe des Hauptinhaltes einzuschränken.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['sortFields'] = array("Sortierung", "Wählen Sie die Felder in der Reihenfolge aus in der die gefundenen Inhalte sortiert werden sollen.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['sortDirection'] = array("Sortierrichtung", "Wählen Sie hier die Richtung aus in der Sortiert werden soll.");
$GLOBALS['TL_LANG']['tl_ynfinite_filter']['alias'] = array("Alias", "Dieses Feld wird als Alias für Weiterleitungen verwendet.");