<?php

$GLOBALS['TL_LANG']['tl_settings']['ynfinite_legend'] = "Ynfinite Einstellungen";
$GLOBALS['TL_LANG']['tl_settings']['ynfinite_api_token'] = array("API Token", "Tragen Sie hier den API Token ein den Sie in ihrem Ynfinite Account unter Einstellungen generiert haben.");
$GLOBALS['TL_LANG']['tl_settings']['ynfinite_cms_id'] = array("Contao Id", "Lassen Sie dieses Feld leer. Es wird automatisch eine ID generiert welche das CMS mit dem API Token verbindet.");