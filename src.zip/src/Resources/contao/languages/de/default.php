<?php

$GLOBALS['TL_LANG']['CTE']['ynfinite'] = "Ynfinite";

$GLOBALS['TL_LANG']['CTE']['ynfinite_form'] = array("Formular", "Ein Formular um Daten in Ynfinite einzuspielen.");
$GLOBALS['TL_LANG']['CTE']['ynfinite_filter_form'] = array("Filterformular", "Ein Formular um Inhalte gefiltert aus Ihrem Ynfinite aufrufen zu können.");
$GLOBALS['TL_LANG']['CTE']['ynfinite_content_list'] = array("Inhalt Liste", "Lädt mehrere Inhalte anhand eines Filters aus Ihrem Ynfinite.");
$GLOBALS['TL_LANG']['CTE']['ynfinite_content_single'] = array("Einzelner Inhalt", "Lädt einen Inhalt aus Ihrem Ynfinite anhand einer übergebenen Id.");