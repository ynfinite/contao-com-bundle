<?php

$GLOBALS['TL_DCA']['tl_module']['palettes']['ynfinite_article_list'] = '{title_legend},name,headline,type;{config_legend},skipFirst,inColumn;{reference_legend:hide},defineRoot;{template_legend:hide},customTpl;{protected_legend:hide},protected;{expert_legend:hide},guests,cssID,space';